# Licence d'utilisation de DeFiPilot / DeFiPilot Usage License

## Français :

Ce logiciel, DeFiPilot, est mis à disposition gratuitement pour une utilisation personnelle, éducative et non commerciale uniquement.

Il est interdit :
- d'utiliser ce logiciel dans un contexte commercial ou professionnel ;
- de vendre, redistribuer ou intégrer ce logiciel dans un produit payant ;
- d'utiliser ce logiciel pour fournir des services rémunérés.

Toute demande d’usage commercial doit faire l’objet d’une autorisation écrite préalable de l’auteur.

L’auteur ne garantit pas le fonctionnement du logiciel et décline toute responsabilité en cas de bug, perte ou dommage.

---

## English:

This software, DeFiPilot, is provided free of charge for personal, educational, and non-commercial use only.

It is strictly forbidden to:
- use this software in any commercial or professional context;
- sell, redistribute, or include this software in a paid product;
- use this software to offer paid services.

Any commercial usage requires prior written authorization from the author.

The author makes no warranty and accepts no liability for bugs, losses, or damages.
