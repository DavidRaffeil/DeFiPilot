FR : Dossier destiné à contenir des “instantanés” de l’état du portefeuille ou de la simulation à un moment donné.  
EN : Folder intended to store “snapshots” of the portfolio or simulation state at a given moment.
