FR : Statistiques détaillées générées à chaque cycle de simulation (scores, durée, rendement, etc.).  
EN : Detailed statistics generated for each simulation cycle (scores, duration, returns, etc.).
