FR : Rapports générés automatiquement à la fin de chaque journée de simulation.  
EN : Reports automatically generated at the end of each simulation day.
