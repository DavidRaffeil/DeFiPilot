import simulateur_wallet

# Simulation d’un gain fictif
gain = 12.5
nouveau_solde = simulateur_wallet.mettre_a_jour_solde(gain)

print(f"Nouveau solde simulé : {nouveau_solde}")
